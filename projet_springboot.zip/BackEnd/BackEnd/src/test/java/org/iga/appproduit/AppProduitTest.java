package org.iga.appproduit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppProduitApplicationTests {

	@Test
	void contextLoads() {
	}

}
